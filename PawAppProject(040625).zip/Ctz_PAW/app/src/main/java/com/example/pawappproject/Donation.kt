package com.example.pawappproject

data class Donation(
    val id: String = "",
    val name: String = "",
    val purpose: String = "",
    val gcashName: String = "",
    val gcashNumber: String = "",
    val details: String = ""
)
